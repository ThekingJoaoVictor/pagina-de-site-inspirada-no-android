        document.getElementById('registrationForm').addEventListener('sbmit', function(event) {
        event.preventDefault();
        alert('Formulario enviado com sucesso')
    });